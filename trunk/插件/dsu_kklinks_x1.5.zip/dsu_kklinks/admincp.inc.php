<?php
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$config=$_G['cache']['plugin']['dsu_kklinks'];
$base_link='action=plugins&operation=config&identifier=dsu_kklinks&pmod=admincp';
if (!$_G['gp_checking']){
	cpmsg('dsu_kklinks:jumping',$base_link.'&checking=yes','infotitle1');
}
$base_link=$base_link.'&checking=yes';
if ($_G['gp_id']){
	if (!submitcheck('message')){
		if ($_G['gp_doadd']){
			showformheader('plugins&operation=config&identifier=dsu_kklinks&pmod=admincp&checking=yes&doadd=yes&id='.$_G['gp_id']);
			showtableheader(lang('plugin/dsu_kklinks','mod_link'));
			showsetting(lang('plugin/dsu_kklinks','mod_msg_succeed'), 'message', lang('plugin/dsu_kklinks','mod_msg_succeed_example'), 'textarea');
		}elseif ($_G['gp_dodel']){
			showformheader('plugins&operation=config&identifier=dsu_kklinks&pmod=admincp&checking=yes&dodel=yes&id='.$_G['gp_id']);
			showtableheader(lang('plugin/dsu_kklinks','mod_link'));
			showsetting(lang('plugin/dsu_kklinks','mod_msg_error'), 'message', lang('plugin/dsu_kklinks','mod_msg_error_example'), 'textarea');
		}
		showsubmit('submit');
		showformfooter();
		showtablefooter();
		exit();
	}
	if ($_G['gp_doadd']){
		$addlink=DB::fetch_first('SELECT * FROM '.DB::table('dsu_kklinks').' WHERE id='.$_G['gp_id']);
		foreach($addlink as $key=>$value){
			$addlink[$key]=addslashes($addlink[$key]);
		}
		if (!$addlink['tid']) cpmsg('dsu_kklinks:mod_no_need','','error');
		DB::insert('common_friendlink', array(
			'name'=>$addlink['name'],
			'url'=>$addlink['url'],
			'logo'=>$addlink['logo'],
			'type'=>'2'));
		updatecache();
		$reply_pid=insertpost(array(
		'tid'=>$addlink['tid'],
		'fid'=>$config['forum'],
		'first'=>'0',
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'dateline'=>$_G['timestamp'],
		'message'=>$_G['gp_message'],
		'useip'=>$_G['clientip']));
		DB::query('UPDATE '.DB::table('forum_thread')." SET replies=replies+'1' WHERE tid=".$addlink['tid']);
		DB::query('UPDATE '.DB::table('forum_forum')." SET posts=posts+'1',lastpost='".$addlink['tid'].'	'.$addlink['name'].' '.lang('plugin/dsu_kklinks','addlink').'	'.TIMESTAMP.'	'.$_G['username']."' WHERE fid=".$config['forum']);
		$post_uid=DB::fetch_first('SELECT authorid FROM '.DB::table('forum_thread').' WHERE tid='.$addlink['tid']);
		notification_add($post_uid['authorid'], 'post', 'reppost_noticeauthor', array(
			'tid' => $addlink['tid'],
			'subject' => $addlink['name'].' '.lang('plugin/dsu_kklinks','addlink'),
			'noticeauthormsg' => $addlink['name'].' '.lang('plugin/dsu_kklinks','addlink'),
			'postmsg' => cutstr($_G['gp_message'], 200),
			'fid' => $config['forum'],
			'pid' => $reply_pid,
		));
		DB::query('DELETE FROM '.DB::table('dsu_kklinks').' WHERE id='.$_G['gp_id']);
		cpmsg('dsu_kklinks:action_succeed',$base_link,'succeed');
	}elseif($_G['gp_dodel']){
		$addlink=DB::fetch_first('SELECT * FROM '.DB::table('dsu_kklinks').' WHERE id='.$_G['gp_id']);
		foreach($addlink as $key=>$value){
			$addlink[$key]=addslashes($addlink[$key]);
		}
		if (!$addlink['tid']) cpmsg('dsu_kklinks:mod_no_need','','error');
		$reply_pid=insertpost(array(
		'tid'=>$addlink['tid'],
		'fid'=>$config['forum'],
		'first'=>'0',
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'dateline'=>$_G['timestamp'],
		'message'=>$_G['gp_message'],
		'useip'=>$_G['clientip']));
		DB::query('UPDATE '.DB::table('forum_thread')." SET replies=replies+'1' WHERE tid=".$addlink['tid']);
		DB::query('UPDATE '.DB::table('forum_forum')." SET posts=posts+'1',lastpost='".$addlink['tid'].'	'.$addlink['name'].' '.lang('plugin/dsu_kklinks','addlink').'	'.TIMESTAMP.'	'.$_G['username']."' WHERE fid=".$config['forum']);
		$post_uid=DB::fetch_first('SELECT authorid FROM '.DB::table('forum_thread').' WHERE tid='.$addlink['tid']);
		notification_add($post_uid['authorid'], 'post', 'reppost_noticeauthor', array(
			'tid' => $addlink['tid'],
			'subject' => $addlink['name'].' '.lang('plugin/dsu_kklinks','addlink'),
			'noticeauthormsg' => $addlink['name'].' '.lang('plugin/dsu_kklinks','addlink'),
			'postmsg' => cutstr($_G['gp_message'], 200),
			'fid' => $config['forum'],
			'pid' => $reply_pid,
		));
		DB::query('DELETE FROM '.DB::table('dsu_kklinks').' WHERE id='.$_G['gp_id']);
		cpmsg('dsu_kklinks:action_succeed',$base_link,'succeed');
	}
}
function check_status($url){
	global $config;
	if (get_cfg_var('allow_url_fopen')<>1){
		return lang('plugin/dsu_kklinks','status_not');
	}
	$content=file_get_contents($url);
	if (strpos($content,$config['dzurl'])){
		return lang('plugin/dsu_kklinks','status_ok');
	}else{
		return lang('plugin/dsu_kklinks','status_no');
	}
}
$count=DB::query('SELECT COUNT(*) FROM '.DB::table('dsu_kklinks'));
$count=DB::result($count);
if ($count<1){
	cpmsg('dsu_kklinks:no_need','','succeed');
}
showtableheader();
showsubtitle(array(lang('plugin/dsu_kklinks','menu1'),lang('plugin/dsu_kklinks','menu2'),lang('plugin/dsu_kklinks','menu3'),lang('plugin/dsu_kklinks','menu4'),lang('plugin/dsu_kklinks','menu5'),lang('plugin/dsu_kklinks','menu6'),lang('plugin/dsu_kklinks','menu7')));
$query = DB::query('SELECT * FROM '.DB::table('dsu_kklinks'));
$exit=true;
while($linkinfo = DB::fetch($query)) {
	$exit=false;
	showtablerow('','',array($linkinfo['name'],'<a href="'.$linkinfo['url'].'">'.$linkinfo['url'].'</a>','<a href="'.$linkinfo['logo'].'">'.$linkinfo['logo'].'</a>',$linkinfo['introduce'],$linkinfo['other'],lang('plugin/dsu_kklinks','admin_action',array('id'=>$linkinfo['id'],'base_link'=>$base_link)),check_status($linkinfo['url'])));
}
showtablefooter();