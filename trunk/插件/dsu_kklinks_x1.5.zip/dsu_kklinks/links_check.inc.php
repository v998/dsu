<?php
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$base_link='action=plugins&operation=config&identifier=dsu_kklinks&pmod=links_check';
if (submitcheck('delid',1)){
	DB::query('DELETE FROM '.DB::table('common_friendlink').' WHERE id='.intval($_G['gp_delid']));
	updatecache();
	cpmsg('dsu_kklinks:del_succeed',$base_link,'succeed');
}
showtips(lang('plugin/dsu_kklinks','tips'));
if (!$_G['gp_checking']){
	cpmsg('dsu_kklinks:jumping',$base_link.'&checking=yes','infotitle1');
}
$base_link=$base_link.'&checking=yes';
loadcache('plugin');
$config=$_G['cache']['plugin']['dsu_kklinks'];
function check_status($url){
	global $config;
	if (get_cfg_var('allow_url_fopen')<>1){
		return lang('plugin/dsu_kklinks','status_not');
	}
	$content=file_get_contents($url);
	if (strpos($content,$config['dzurl'])){
		return lang('plugin/dsu_kklinks','status_ok');
	}else{
		return lang('plugin/dsu_kklinks','status_no');
	}
}
showtableheader();
showsubtitle(array(lang('plugin/dsu_kklinks','menu1'),lang('plugin/dsu_kklinks','menu2'),lang('plugin/dsu_kklinks','menu3'),lang('plugin/dsu_kklinks','menu7'),lang('plugin/dsu_kklinks','menu6')));
$query = DB::query('SELECT * FROM '.DB::table('common_friendlink')." WHERE url!='plugin.php?id=dsu_kklinks:addlink'");
while($linkinfo = DB::fetch($query)) {
	showtablerow('','',array($linkinfo['name'],'<a href="'.$linkinfo['url'].'">'.$linkinfo['url'].'</a>','<a href="'.$linkinfo['logo'].'">'.$linkinfo['logo'].'</a>',check_status($linkinfo['url']),lang('plugin/dsu_kklinks','action_del',array('id'=>$linkinfo['id'],'formhash'=>FORMHASH,'base_link'=>$base_link))));
}
showtablefooter();