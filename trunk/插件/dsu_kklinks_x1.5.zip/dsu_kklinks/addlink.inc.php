<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$config=$_G['cache']['plugin']['dsu_kklinks'];
$config['readme']=nl2br($config['readme']);
foreach($_G as $key=>$value){
	!is_array($_G[$key]) && $_G[$key]=strip_tags($_G[$key]);
}
function check_status($url){
	if (get_cfg_var('allow_url_fopen')<>1) return true;
	global $config;
	$content=file_get_contents($url);
	if (strpos($content,$config['dzurl'])){
		return true;
	}else{
		return false;
	}
}
if (!$_G['gp_submit']){
	$countdown=intval($config['countdown']);
	if (!$_G['inajax']){
		include template('dsu_kklinks:addlink');
	}else{
		include template('dsu_kklinks:addlink_ajax');
	}
}else{
	@preg_match("/^http:\/\/([^\/%\[\t\"''?=&]+)/i", $_G['gp_url'], $match_url);
	if (!$_G['gp_sitename']||!$match_url[0]||!$_G['gp_introduce']){
		//showmessage('dsu_kklinks:need_more');
	}
	$link_exist=DB::fetch_first('SELECT url FROM '.DB::table('common_friendlink')." WHERE url LIKE '%".$match_url[1]."%'");
	if(!empty($link_exist)){
		showmessage('dsu_kklinks:error_exist1');
	}
	$submit_exist=DB::fetch_first('SELECT url FROM '.DB::table('dsu_kklinks')." WHERE url LIKE '%".$match_url[1]."%'");
	if(!empty($submit_exist)){
		showmessage('dsu_kklinks:error_exist2');
	}
	$url=$match_url[0].'/';
	$blacklists=explode("\n", str_replace("\r","\n",$config['blacklist']));
	foreach ($blacklists as $blacklist){
		if (strpos($url,$blacklist)){
			showmessage('dsu_kklinks:blacklisted');
		}
	}
	if ($config['check_link'] && !check_status($url)){
		showmessage('dsu_kklinks:no_link');
	}
	$tid=insertpost(array(
		'fid'=>$config['forum'],
		'first'=>'1',
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'subject'=>$_G['gp_sitename'].' '.lang('plugin/dsu_kklinks','addlink'),
		'dateline'=>$_G['timestamp'],
		'message'=>lang('plugin/dsu_kklinks','message',array(
			'sitename'=>$_G['gp_sitename'],
			'url'=>$url,
			'logo'=>$_G['gp_logo'],
			'introduce'=>$_G['gp_introduce'],
			'other_info'=>$_G['gp_other_info'],
		)),
		'useip'=>$_G['clientip']));
	DB::insert('forum_thread', array(
		'tid'=>$tid,
		'fid'=>$config['forum'],
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'subject' => $_G['gp_sitename'].' '.lang('plugin/dsu_kklinks','addlink'),
		'dateline' => $_G['timestamp'],
		'lastpost' => $_G['timestamp'],
		'lastposter'=>$_G['username'],
		'closed'=>1));
	DB::insert('dsu_kklinks', array(
		'tid'=>$tid,
		'name'=>$_G['gp_sitename'],
		'url'=>$url,
		'logo'=>$_G['gp_logo'],
		'introduce'=>$_G['gp_introduce'],
		'other'=>$_G['gp_other_info']));
	DB::query('UPDATE '.DB::table('forum_post')." SET tid=pid,tags='' WHERE pid=".$tid);
	DB::query('UPDATE '.DB::table('forum_forum')." SET threads=threads+'1',lastpost='{$tid}	".$_G['gp_sitename'].' '.lang('plugin/dsu_kklinks','addlink').'	'.TIMESTAMP.'	'.$_G['username']."' WHERE fid=".$config['forum']);
	showmessage('dsu_kklinks:submit_succeed','forum.php?mod=viewthread&tid='.$tid,array(),array('locationtime'=>2,'showdialog'=>1,'showmsg'=>true,'closetime'=>3));
}
?>