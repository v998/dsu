<?php
class plugin_dsu_kklinks{
	function index_links_output(){
		global $_G;
		$find='plugin.php?id=dsu_kklinks:addlink';
		$replace='plugin.php?id=dsu_kklinks:addlink" onclick="showWindow(\'dsu_kklinks\', this.href)';
		$_G['cache']['forumlinks'][0]=str_replace($find,$replace,$_G['cache']['forumlinks'][0]);
		$_G['cache']['forumlinks'][1]=str_replace($find,$replace,$_G['cache']['forumlinks'][1]);
		$_G['cache']['forumlinks'][2]=str_replace($find,$replace,$_G['cache']['forumlinks'][2]);
	}
	function post_links(){
		global $_G;
		loadcache('plugin');
		$config=$_G['cache']['plugin']['dsu_kklinks'];
		if ($config['forum'] && $config['lockforum'] && $_G['gp_action']=='newthread' && $_G['fid']==$config['forum']){
			if ($_G['gp_inajax']){
				showmessage('dsu_kklinks:can_not_post_link');
			}else{
				showmessage('dsu_kklinks:can_not_post','plugin.php?id=dsu_kklinks:addlink');
			}
		}
	}
}

class plugin_dsu_kklinks_forum extends plugin_dsu_kklinks {
}