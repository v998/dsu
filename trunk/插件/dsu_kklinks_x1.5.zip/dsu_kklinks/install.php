<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql=<<<EOF
CREATE TABLE IF NOT EXISTS pre_dsu_kklinks (
  id tinyint(4) auto_increment,
  tid smallint(6),
  name text,
  url text,
  logo text,
  introduce text,
  other text,
  PRIMARY KEY (id)
) ENGINE=MyISAM;
EOF;
runquery($sql);

@include 'stat.php';

$finish = TRUE;