<?php
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$config=$_G['cache']['plugin']['dsu_kkvip'];
header("Location: admin.php?action=usergroups&operation=edit&id=".$config['vip_group']);