<?php

function sign_vip($num){
	global $_G;
	loadcache('plugin');
	$config=$_G['cache']['plugin']['dsu_kkvip'];
	include DISCUZ_ROOT.'./source/plugin/dsu_kkvip/config/sign.inc.php';
	if (!$use_sign) return false;
	if ($num==1){
		pay_vip($_G['uid'],$free_vip_days,$_G['groupid']);
		notification_add($_G['uid'],'dsu_kkvip',lang('plugin/dsu_kkvip','notification_1'),array('days'=>$free_vip_days),1);
	}elseif ($num<=$add_czz_num){
		if (check_vip($_G['uid'])){
			add_czz_vip($_G['uid'],$czz_num);
			notification_add($_G['uid'],'dsu_kkvip',lang('plugin/dsu_kkvip','notification_2'),array('num'=>$num,'czz'=>$czz_num),1);
		}
	}
}

function pay_vip($uid,$day,$oldgroup){
	global $_G;
	loadcache('plugin');
	$config=$_G['cache']['plugin']['dsu_kkvip'];
	if (!$uid) return;
	if (intval($day)!=$day || $day<=0) return false;
	$query=DB::fetch_first('SELECT * FROM '.DB::table('dsu_kkvip').' WHERE uid='.$uid.' AND endtime>'.TIMESTAMP);
	if (!$query['uid']){
		$query=DB::fetch_first('SELECT uid FROM '.DB::table('dsu_kkvip').' WHERE uid='.$uid);
		if (!$query['uid']){
			DB::query('INSERT INTO '.DB::table("dsu_kkvip").' (uid,endtime,czz,oldgroup,usevip,regtime) VALUES ('.$uid.','.(TIMESTAMP+86400*$day).',0,'.$oldgroup.',1,'.TIMESTAMP.');');
		}else{
			DB::query('UPDATE '.DB::table("dsu_kkvip").' SET endtime='.(TIMESTAMP+86400*$day).' WHERE uid='.$uid.';');
		}
	}else{
		DB::query('UPDATE '.DB::table("dsu_kkvip").' SET endtime=endtime+'.(86400*$day).' WHERE uid='.$uid.';');
		return;
	}
	DB::query('UPDATE '.DB::table("common_member").' SET groupid='.$config['vip_group'].' WHERE uid='.$uid.' AND adminid=0');
	return;
}

function add_czz_vip($uid,$num){
	if (!$uid) return;
	if (intval($num)!=$num || $num<=0) return false;
	if (is_array($uid)){
		foreach($uid as $user){
			$users.=$users ? ','.$user : $user;
		}
		DB::query("UPDATE ".DB::table("dsu_kkvip")." SET czz=czz+'".$num."' WHERE uid IN (".$users.")");
		return true;
	}
	DB::query("UPDATE ".DB::table("dsu_kkvip")." SET czz=czz+'".$num."' WHERE uid=".$uid);
	return true;
}

function check_vip($uid){
	$query=DB::fetch_first('SELECT * FROM '.DB::table('dsu_kkvip').' WHERE uid='.$uid.' AND endtime>'.TIMESTAMP);
	if ($query['uid']){
		return true;
	}else{
		return false;
	}
}
