<?php
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (submitcheck('submit')){
	$del_arr=(array)$_G['gp_delete'];
	$new_arr=(array)$_G['gp_newmoney'];
	if($del_arr){
		foreach ($_G['gp_delete'] as $item){
			if($item){
				$del_ids.=$del_ids ? ",'{$item}'" : "'{$item}'";
			}
		}
		if($del_ids){
			DB::delete('dsu_kkvip_codes', "id IN ({$del_ids})");
		}
	}
	if($new_arr){
		foreach ($_G['gp_newmoney'] as $item){
			if($item){
				$temp_arr['code']=random(16);
				$temp_arr['money']=$item;
				DB::insert('dsu_kkvip_codes', $temp_arr);
			}
		}
	}
	cpmsg("dsu_kkvip:plugin_inc_php_1",'action=plugins&operation=config&identifier=dsu_kkvip&pmod=discount','succeed');
}

if($_G['gp_showlogs']){
	if (submitcheck('clean')){
		DB::query('TRUNCATE TABLE '.DB::table('dsu_kkvip_codelog'));
	}
	showformheader('plugins&operation=config&identifier=dsu_kkvip&pmod=discount&showlogs=yes');
	showtableheader(lang("plugin/dsu_kkvip","discount_inc_php_2"));
	showsubtitle(array(lang("plugin/dsu_kkvip","discount_inc_php_3"), lang("plugin/dsu_kkvip","discount_inc_php_4"), lang("plugin/dsu_kkvip","discount_inc_php_5"), lang("plugin/dsu_kkvip","discount_inc_php_6")));
	$page=$_G['gp_page'] ? intval($_G['gp_page']) : 1;
	$start=($page-1)*15;
	$query=DB::query('SELECT m.username, l.code, l.money, l.time FROM '.DB::table('dsu_kkvip_codelog').' l, '.DB::table('common_member')." m WHERE l.uid=m.uid ORDER BY l.id DESC LIMIT {$start},15");
	while($result=DB::fetch($query)){
		showtablerow('', array('class="td26"', 'class="td28"', 'class="td26"'), array(
			$result['username'],
			$result['code'],
			dgmdate($result['time'],'u'),
			$result['money'],
		));
	}
	$amount=DB::result_first('SELECT COUNT(*) FROM '.DB::table('dsu_kkvip_codelog'));
	$multi=multi($amount, 15, $page, 'admin.php?action=plugins&operation=config&identifier=dsu_kkvip&pmod=discount&showlogs=yes', 0, 10, 1, 1);
	showsubmit('clean', lang("plugin/dsu_kkvip","discount_inc_php_7"), '' , '<a href="admin.php?action=plugins&amp;operation=config&amp;identifier=dsu_kkvip&pmod=discount">'.lang("plugin/dsu_kkvip","discount_inc_php_11").'</a> &nbsp; <a href="admin.php?action=plugins&operation=config&identifier=dsu_kkvip&pmod=discount&showlogs=yes">'.lang("plugin/dsu_kkvip","discount_inc_php_12").'</a>', $multi);
	showtablefooter();
	showformfooter();
	exit();
}

echo '<script type="text/JavaScript">
var rowtypedata = [[
	[1,"", "td25"],
	[1,"'.lang("plugin/dsu_kkvip","discount_inc_php_13").'", "td28"],
	[1,"'.lang("plugin/dsu_kkvip","discount_inc_php_13").'", "td28"],
	[1,\'<input type="text" class="txt" name="newmoney[]" size="3">\', "td26"],
]]
</script>';
showformheader('plugins&operation=config&identifier=dsu_kkvip&pmod=discount');
showtableheader(lang("plugin/dsu_kkvip","discount_inc_php_8"));
showsubtitle(array('', lang("plugin/dsu_kkvip","discount_inc_php_15"), lang("plugin/dsu_kkvip","discount_inc_php_9"), lang("plugin/dsu_kkvip","discount_inc_php_6")));
$page=$_G['gp_page'] ? intval($_G['gp_page']) : 1;
$start=($page-1)*10;
$query=DB::query('SELECT * FROM '.DB::table('dsu_kkvip_codes')." ORDER BY id DESC LIMIT {$start},10");
while($result=DB::fetch($query)){
	showtablerow('', array('class="td25"', 'class="td28"', 'class="td26"'), array(
		'<input type="checkbox" class="checkbox" name="delete[]" value="'.$result['id'].'" />',
		'<input type="text" onclick="this.select()" value="'.$result['code'].'" size="50" />',
		'<input type="text" onclick="this.select()" value="[VIP]'.$result['code'].'[/VIP]" size="65" />',
		$result['money'],
	));
}
echo '<tr><td></td><td colspan="3"><div><a href="#addrow" name="addrow" onclick="addrow(this, 0)" class="addtr">'.lang("plugin/dsu_kkvip","discount_inc_php_17").'</a></div></td></tr>';
$amount=DB::result_first('SELECT COUNT(*) FROM '.DB::table('dsu_kkvip_codes'));
$multi=multi($amount, 10, $page, 'admin.php?action=plugins&operation=config&identifier=dsu_kkvip&pmod=discount', 0, 10, 1, 1);
showsubmit('submit', 'submit', 'del' , '<a href="admin.php?action=plugins&operation=config&identifier=dsu_kkvip&pmod=discount&showlogs=yes">'.lang("plugin/dsu_kkvip","discount_inc_php_18").'</a>', $multi);
showtablefooter();
showformfooter();