<?php
!defined('IN_ADMINCP') && exit('Access Denied');
loadcache("plugin");
$config=$_G['cache']['plugin']['dsu_kkvip'];
if (submitcheck('plugin')){
	$output='<?php
/**
 * VIP plugin Setting
 */
!defined("IN_DISCUZ") && exit("Access Denied");

$use_sign=\''.$_G['gp_use_sign'].'\';
$free_vip_days=\''.$_G['gp_free_vip_days'].'\';
$add_czz_num=\''.$_G['gp_add_czz_num'].'\';
$czz_num=\''.$_G['gp_czz_num'].'\';
?>';
	@mkdir(DISCUZ_ROOT.'./source/plugin/dsu_kkvip/config',0777);
	file_put_contents(DISCUZ_ROOT.'./source/plugin/dsu_kkvip/config/sign.inc.php',$output);
	cpmsg("dsu_kkvip:plugin_inc_php_1",'action=plugins&operation=config&identifier=dsu_kkvip&pmod=plugin','succeed');
}
include DISCUZ_ROOT.'./source/plugin/dsu_kkvip/config/sign.inc.php';
showtableheader(lang("plugin/dsu_kkvip","plugin_inc_php_6"));
showformheader("plugins&operation=config&identifier=dsu_kkvip&pmod=plugin&plugin=sign", "");
showsetting(lang("plugin/dsu_kkvip","plugin_inc_php_2"), 'use_sign', ($use_sign!==null?$use_sign:1), 'radio');
showsetting(lang("plugin/dsu_kkvip","plugin_inc_php_3"), 'free_vip_days', ($free_vip_days!==null?$free_vip_days:7), 'number');
showsetting(lang("plugin/dsu_kkvip","plugin_inc_php_4"), 'add_czz_num', ($add_czz_num!==null?$add_czz_num:10), 'number');
showsetting(lang("plugin/dsu_kkvip","plugin_inc_php_5"), 'czz_num', ($czz_num!==null?$czz_num:50), 'number');
showsubmit('submit');
showformfooter();
showtablefooter();