<?php
/**
 * [DSU] VIP
 * Check expire VIP users.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$config=$_G['cache']['plugin']['dsu_kkvip'];
DB::query('UPDATE '.DB::table('dsu_kkvip')." SET czz=czz+'".$config['vip_czzday']."' WHERE endtime>".TIMESTAMP, 'UNBUFFERED');
DB::query('UPDATE '.DB::table('dsu_kkvip')." SET czz=czz-'".$config['vip_czzday2']."' WHERE endtime<=".TIMESTAMP, 'UNBUFFERED');
DB::query('DELETE FROM '.DB::table('dsu_kkvip').' WHERE czz<=0 AND endtime<='.TIMESTAMP, 'UNBUFFERED');
