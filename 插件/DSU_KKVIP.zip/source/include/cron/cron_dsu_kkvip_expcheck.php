<?php
/*
 * [DSU] VIP
 * Check expire VIP users.
 */

$sql='UPDATE '.DB::table('common_member').' m, '.DB::table('dsu_kkvip').' v SET m.groupid=v.oldgroup WHERE m.uid=v.uid AND v.endtime<='.TIMESTAMP;
DB::query($sql, 'UNBUFFERED');

?>