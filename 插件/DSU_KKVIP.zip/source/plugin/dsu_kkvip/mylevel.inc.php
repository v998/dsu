<?php
!defined('IN_KKVIP') && exit('Access Denied');
$vip_intro_array=explode("\n",$config['vip_intro']);
foreach ($vip_intro_array as $text){
	$vip_intro.=$text?"<li>".$text."</li>\r\n":"";
}
switch ($_G['vip']['level']) {
	case 5:
		$update_days=round((10800-$_G['vip']['czz'])/$config['vip_czzday']);
		$update_time=date("Y-m-d",TIMESTAMP+$update_days*86400);
		$next_level=6;
		break;
	case 4:
		$update_days=round((6000-$_G['vip']['czz'])/$config['vip_czzday']);
		$update_time=date("Y-m-d",TIMESTAMP+$update_days*86400);
		$next_level=5;
		break;
	case 3:
		$update_days=round((3600-$_G['vip']['czz'])/$config['vip_czzday']);
		$update_time=date("Y-m-d",TIMESTAMP+$update_days*86400);
		$next_level=4;
		break;
	case 2:
		$update_days=round((1800-$_G['vip']['czz'])/$config['vip_czzday']);
		$update_time=date("Y-m-d",TIMESTAMP+$update_days*86400);
		$next_level=3;
		break;
	case 1:
		$update_days=round((600-$_G['vip']['czz'])/$config['vip_czzday']);
		$update_time=date("Y-m-d",TIMESTAMP+$update_days*86400);
		$next_level=2;
		break;
}
include template('dsu_kkvip:mylevel');