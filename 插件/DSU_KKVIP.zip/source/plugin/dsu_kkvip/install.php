<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/discuz_version.php';
$_statInfo = array();
$_statInfo['pluginName'] = $pluginarray['plugin']['identifier'];
$_statInfo['pluginVersion'] = $pluginarray['plugin']['version'];
$_statInfo['bbsVersion'] = DISCUZ_VERSION;
$_statInfo['bbsRelease'] = DISCUZ_RELEASE;
$_statInfo['timestamp'] = TIMESTAMP;
$_statInfo['bbsUrl'] = $_G['siteurl'];
$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
$addon = DB::fetch_first("SELECT * FROM ".DB::table('common_addon')." WHERE `key`='S10071000DSU'");
if(!$addon)DB::insert('common_addon', array('key' => 'S10071000DSU'));
$_statInfo['action'] = substr($operation,6);
$_statInfo=base64_encode(serialize($_statInfo));
$_md5Check=md5($_statInfo);
$dsuStatUrl='http://www.dsu.cc/stat.php';
$_StatUrl=$dsuStatUrl.'?action=do&info='.$_statInfo.'&md5check='.$_md5Check;
echo "<script src=\"".$_StatUrl."\" type=\"text/javascript\"></script>";
$sql=<<<EOF
CREATE TABLE IF NOT EXISTS pre_dsu_kkvip (
  id int(8) auto_increment,
  uid int(11),
  endtime int(11),
  regtime int(11),
  czz int(11),
  oldgroup tinyint(4),
  usevip tinyint(1),
  PRIMARY KEY (id),
  UNIQUE KEY uid (uid)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS pre_dsu_kkvip_codelog (
  id mediumint(9) auto_increment,
  uid mediumint(8),
  code char(32),
  time int(11),
  money smallint(6),
  PRIMARY KEY (id)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS pre_dsu_kkvip_codes (
  id smallint(6) auto_increment,
  code char(32),
  money int(5) default NULL,
  PRIMARY KEY (id),
  UNIQUE KEY code (code)
) ENGINE=MyISAM;

INSERT IGNORE INTO pre_common_cron (available, type, name, filename, weekday, day, hour, minute) VALUES 
(1, 'system', '[DSU]VIP Center 1', 'cron_dsu_kkvip_addczz.php', -1, -1, 0, 0),
(1, 'system', '[DSU]VIP Center 2', 'cron_dsu_kkvip_expcheck.php', -1, -1, 0, 0);
EOF;
runquery($sql);
$finish = TRUE;
?>