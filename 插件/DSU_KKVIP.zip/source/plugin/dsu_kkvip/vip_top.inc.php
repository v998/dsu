<?php
!defined('IN_KKVIP') && exit('Access Denied');
$vip_intro_array=explode("\n",$config['vip_intro']);
foreach ($vip_intro_array as $text){
	$vip_intro.=$text?"<li>".$text."</li>\r\n":"";
}
$query=DB::query("SELECT m.username,m.uid,v.czz FROM ".DB::table("dsu_kkvip")." v,".DB::table("common_member")." m WHERE m.uid=v.uid ORDER BY v.czz DESC LIMIT 0,15");
while($value=DB::fetch($query)){
	if ($value['czz']>=10800){ $value['level']=6; }
	elseif ($value['czz']>=6000){ $value['level']=5; }
	elseif ($value['czz']>=3600){ $value['level']=4; }
	elseif ($value['czz']>=1800){ $value['level']=3; }
	elseif ($value['czz']>=600){ $value['level']=2; }
	else {$value['level']=1; }
	$viparray[]=$value;
}
include template('dsu_kkvip:vip_top');