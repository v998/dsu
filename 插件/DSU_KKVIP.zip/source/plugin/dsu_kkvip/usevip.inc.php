<?php
if(!defined('IN_KKVIP') || !$_G['adminid']) {
	exit('Access Denied');
}
$config=$_G['cache']['plugin']['dsu_kkvip'];
if(!$_G['vip']['isvip'] && !$_G['vip']['not_usevip']){
	header("Location: vip.php?do=paycenter");
}
$usevip_text=$_G['vip']['not_usevip']?lang('plugin/dsu_kkvip','usevip_no'):lang('plugin/dsu_kkvip','usevip_yes');
if (submitcheck('submit',1)){
	if (!in_array($_G['gp_status'],array(0,1))) exit('Access Denied');
	DB::update('dsu_kkvip', array('usevip'=>$_G['gp_status']), array('uid' => $_G['uid']));
	include template('common/header_ajax');
	echo lang('plugin/dsu_kkvip','saved_'.($_G['gp_status']?1:0));
	include template('common/footer_ajax');
	exit();
}
include template('dsu_kkvip:usevip');