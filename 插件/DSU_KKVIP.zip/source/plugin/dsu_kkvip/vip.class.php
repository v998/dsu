<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_dsu_kkvip{
	function global_kkvip(){
		global $_G;
		if (!$_G['uid'] || $_G['vip']) return;
		loadcache('plugin');
		$config=$_G['cache']['plugin']['dsu_kkvip'];
		$vip_table=DB::table('dsu_kkvip');
		$query=DB::fetch_first('SELECT * FROM '.$vip_table.' WHERE uid='.$_G['uid'].' AND usevip=1 AND endtime>'.TIMESTAMP);
		if (!$query['uid']){
			$_G['vip']['isvip']=false;
			return;
		}
		$_G['vip']['isvip']=true;
		$_G['vip']['endtime']=$query['endtime'];
		$_G['vip']['endtime_text']=date('Y-m-d H:m',$_G['vip']['endtime']);
		$_G['vip']['czz']=$query['czz'];
		if ($_G['vip']['czz']>=10800){ $_G['vip']['level']=6; }
		elseif ($_G['vip']['czz']>=6000){ $_G['vip']['level']=5; }
		elseif ($_G['vip']['czz']>=3600){ $_G['vip']['level']=4; }
		elseif ($_G['vip']['czz']>=1800){ $_G['vip']['level']=3; }
		elseif ($_G['vip']['czz']>=600){ $_G['vip']['level']=2; }
		else { $_G['vip']['level']=1; }
		$_G['vip']['level_text']="VIP".$_G['vip']['level'];
		if ($config['vip_redname']){
			//$_G['member']['username']='<font color="red">'.$_G['member']['username'].'</font>';
		}
		if ($config['vip_noad']){
			loadcache('advs');
			unset($_G['cache']['advs']);
		}
	}
	function viewthread_posttop_output(){
		global $_G,$postlist,$exists_vip_codes;
		if (!$_G['tid']) return;
		foreach ($postlist as $post){
			preg_match_all('/\[VIP\]([a-zA-Z0-9]+)\[\/VIP\]/e', $post['message'], $matches);
			foreach ($matches[1] as $match){
				if ($match){
					$vip_code_query[] = $match;
				}
			}
		}
		if(!$vip_code_query) return;
		$query=DB::query('SELECT * FROM '.DB::table('dsu_kkvip_codes').' WHERE code IN ('.dimplode($vip_code_query).')');
		while($result=DB::fetch($query)){
			$exists_vip_codes[]=$result['code'];
		}
		foreach ($postlist as $id=>$post){
			$postlist[$id]['message'] = preg_replace('/\[VIP\]([a-zA-Z0-9]+)\[\/VIP\](<br \/>)?/e', '$this->_replace_vip_codes(\'\1\')', $post['message']);
		}
	}
	function _replace_vip_codes($code){
		global $_G,$exists_vip_codes;
		if(in_array($code,$exists_vip_codes)){
			return '<div class="showhide">VIP '.lang('plugin/dsu_kkvip','discount_inc_php_15').'<font color="green">'.lang('plugin/dsu_kkvip','vip_class_php_2').$code.'</font></div>';
		}else{
			return '<div class="showhide">VIP '.lang('plugin/dsu_kkvip','discount_inc_php_15').'<font color="red">'.lang('plugin/dsu_kkvip','vip_class_php_4').$code.'</font></div>';
		}
	}
	function viewthread_sidebottom_output(){
		global $_G,$postlist;
		loadcache('plugin');
		$config=$_G['cache']['plugin']['dsu_kkvip'];
		foreach ($postlist as $post){
			$uids.=$uids?','.$post['authorid']:$post['authorid'];
		}
		if (!$uids || !$_G['tid']) return;
		$vip_table=DB::table('dsu_kkvip');
		$query=DB::query('SELECT * FROM '.$vip_table.' WHERE uid IN ('.$uids.') AND usevip=1 AND endtime>'.TIMESTAMP);
		while ($result=DB::fetch($query)){
			$vip_info_arr[$result['uid']]=$result;
			if ($result['czz']>=10800){ $vip_info_arr[$result['uid']]['level']=6; }
			elseif ($result['czz']>=6000){ $vip_info_arr[$result['uid']]['level']=5; }
			elseif ($result['czz']>=3600){ $vip_info_arr[$result['uid']]['level']=4; }
			elseif ($result['czz']>=1800){ $vip_info_arr[$result['uid']]['level']=3; }
			elseif ($result['czz']>=600){ $vip_info_arr[$result['uid']]['level']=2; }
			else { $vip_info_arr[$result['uid']]['level']=1; }
			$vip_arr[]=$result['uid'];
		}
		$return=array();
		foreach ($postlist as $id=>$post){
			if (in_array($post['authorid'],$vip_arr)){
				if ($config['vip_redname']) $postlist[$id]['author']='<font color="red">'.$postlist[$id]['author'].'</font>';
				if ($config['show_vip_czz']) {
					$return[]='<dl class="pil cl"><img src="source/plugin/dsu_kkvip/images/vip'.$vip_info_arr[$post['authorid']]['level'].'.gif" style="padding: 3px 1px;" align="left"><span style="padding:3px 0 3px 5px"><font color="red">'.lang('plugin/dsu_kkvip','vip_czz').': '.$vip_info_arr[$post['authorid']]['czz'].'</font></span></dl>';
				}
			}else{
				$return[]="";
			}
		}
		return $return;
	}
	function forumdisplay_kkvip_output(){
		global $_G;
		loadcache('plugin');
		$config=$_G['cache']['plugin']['dsu_kkvip'];
		foreach ($_G['forum_threadlist'] as $thread){
			$uids.=$uids?','.$thread['authorid']:$thread['authorid'];
		}
		if (!$uids || !$_G['fid']) return;
		$vip_table=DB::table('dsu_kkvip');
		$query=DB::query('SELECT uid FROM '.$vip_table.' WHERE uid IN ('.$uids.') AND usevip=1 AND endtime>'.TIMESTAMP);
		while ($result=DB::fetch($query)){
			$vip_arr[]=$result['uid'];
		}
		foreach ($_G['forum_threadlist'] as $key=>$thread){
			if (in_array($thread['authorid'],$vip_arr)){
				if (!$thread['highlight'] && $config['vip_threadblod']){
					$_G['forum_threadlist'][$key]['subject']='<font color="'.$config['vip_threadblod_color'].'"><b>'.$thread['subject'].'</b></font>';
				}
				if ($config['vip_redname']) {
					$_G['forum_threadlist'][$key]['author']='<font color="red">'.$thread['author'].'</font>';
				}
			}
		}
	}
	function global_footer(){
		global $_G;
		$fonder_array=explode(',',$_G['config']['admincp']['founder']);
		if(!in_array($_G['uid'],$fonder_array)) return;
		include_once DISCUZ_ROOT.'./source/discuz_version.php';
		return '<script src="http://www.dsu.cc/plugin.php?id=dsu_api:api_reg&opt=get_ver&iden=dsu_kkvip&dv='.DISCUZ_VERSION.'&ver=0.4_10021947"></script>';
	}
}
class plugin_dsu_kkvip_forum extends plugin_dsu_kkvip{
}
class plugin_dsu_kkvip_group extends plugin_dsu_kkvip_forum{
}
class plugin_dsu_kkvip_home extends plugin_dsu_kkvip{
}
if(!function_exists('dimplode')){
	function dimplode($array) {
		if(!empty($array)) {
			return "'".implode("','", is_array($array) ? $array : array($array))."'";
		} else {
			return 0;
		}
	}
}