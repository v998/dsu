<?php
/**
 * VIP plugin Setting
 */
!defined("IN_DISCUZ") && exit("Access Denied");

$use_sign='1';
$free_vip_days='7';
$add_czz_num='10';
$czz_num='100';
?>