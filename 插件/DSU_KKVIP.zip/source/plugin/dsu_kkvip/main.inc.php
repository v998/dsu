<?php
!defined('IN_KKVIP') && exit('Access Denied');
define('CURSCRIPT', 'vip');
$_G['basescript']="vip";
$do=$_G['gp_do']?$_G['gp_do']:"vipcenter";
$do=str_replace(array('\\','/'),'',$do);
if (!$_G['uid']) showmessage('not_loggedin','member.php?mod=logging&action=login');
$config=$_G['cache']['plugin']['dsu_kkvip'];
$vip_table=DB::table('dsu_kkvip');
$query=DB::fetch_first('SELECT * FROM '.$vip_table.' WHERE uid='.$_G['uid'].' AND endtime>'.TIMESTAMP);
if (!$query['uid']){
	$_G['vip']['isvip']=false;
	$_G['vip']['endtime']=$query['endtime']?$query['endtime']:time();
	$_G['vip']['endtime_text']=date('Y-m-d H:m',$_G['vip']['endtime']);
	$_G['vip']['czz']=intval($query['czz']);
	$_G['vip']['level_text']="Not VIP";
}else{
	$_G['vip']['isvip']=true;
	if (!$query['usevip']){
		$_G['vip']['not_usevip']=true;
		$_G['vip']['isvip']=false;
	}
	$_G['vip']['endtime']=$query['endtime'];
	$_G['vip']['endtime_text']=date('Y-m-d H:m',$_G['vip']['endtime']);
	$_G['vip']['usevip']=$query['usevip'];
	$_G['vip']['czz']=$query['czz'];
	if ($_G['vip']['czz']>=10800){ $_G['vip']['level']=6; }
	elseif ($_G['vip']['czz']>=6000){ $_G['vip']['level']=5; }
	elseif ($_G['vip']['czz']>=3600){ $_G['vip']['level']=4; }
	elseif ($_G['vip']['czz']>=1800){ $_G['vip']['level']=3; }
	elseif ($_G['vip']['czz']>=600){ $_G['vip']['level']=2; }
	else { $_G['vip']['level']=1; }
	$_G['vip']['level_text']="VIP".$_G['vip']['level'];
}
if (file_exists(DISCUZ_ROOT.'./source/plugin/dsu_kkvip/'.$do.'.inc.php')){
	include DISCUZ_ROOT.'./source/plugin/dsu_kkvip/'.$do.'.inc.php';
}else{
	showmessage('undefined_action');
}