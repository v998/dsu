<?php
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$base_link='action=plugins&operation=config&identifier=dsu_kkvip&pmod=check';
if (!$_G['gp_checking']){
	cpmsg('dsu_kkvip:jumping',$base_link.'&checking=yes','infotitle1');
}
$base_link.='&checking=yes';
$sql='UPDATE '.DB::table('common_member').' m, '.DB::table('dsu_kkvip').' v SET m.groupid=v.oldgroup WHERE m.uid=v.uid AND v.endtime<='.TIMESTAMP;
DB::query($sql);
cpmsg('dsu_kkvip:check_succeed','','succeed',array('sum'=>DB::affected_rows()));