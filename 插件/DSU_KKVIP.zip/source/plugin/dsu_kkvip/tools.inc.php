<?php
!defined('IN_ADMINCP') && exit('Access Denied');
loadcache("plugin");
$config=$_G['cache']['plugin']['dsu_kkvip'];
$search_condition = array_merge($_GET, $_POST);
foreach($search_condition as $k => $v) {
	if(in_array($k, array('action', 'operation', 'formhash', 'submit', 'page')) || $v === '') {
		unset($search_condition[$k]);
	}
}
if (submitcheck('tools_submit',1)){
	$uid_array=explode('|',$_G['gp_uids']);
	if (!check_post_array($uid_array)) exit('Access Denied');
	if (submitcheck('month') && intval($_G['gp_month'])==$_G['gp_month']){
		$uids=dimplode($uid_array);
		$query=DB::query('SELECT * FROM '.DB::table('dsu_kkvip').' WHERE uid IN ('.$uids.')');
		while ($result=DB::fetch($query)){
			if ($result['endtime']>=TIMESTAMP){
				$vip_array[]=$result['uid'];
			}else{
				$old_vip_array[]=$result['uid'];
			}
		}
		$other_user_array=array_remove($uid_array,$vip_array);
		$other_user_array=array_remove($other_user_array,$old_vip_array);
		$vip_uids=dimplode($vip_array);
		if ($vip_uids){
			DB::query('UPDATE '.DB::table("dsu_kkvip").' SET endtime=endtime+'.(86400*30*$_G['gp_month']).' WHERE uid IN ('.$vip_uids.')');
		}
		$old_vip_uids=dimplode($old_vip_array);
		if ($old_vip_uids){
			DB::query('UPDATE '.DB::table("dsu_kkvip").' SET endtime='.(TIMESTAMP+86400*30*$_G['gp_month']).' WHERE uid IN ('.$old_vip_uids.')');
		}
		$update_uids=$old_vip_uids;
		foreach($other_user_array as $other_uid){
			$query=DB::fetch_first('SELECT groupid FROM '.DB::table('common_member').' WHERE uid='.$other_uid);
			DB::query('INSERT INTO '.DB::table("dsu_kkvip").' (uid,endtime,regtime,czz,oldgroup,usevip) VALUES ('.$other_uid.','.(TIMESTAMP+86400*30*$_G['gp_month']).','.TIMESTAMP.',0,'.$query['groupid'].',1);');
			$need_update_uids[]=$other_uid;
		}
		$update_uids=$update_uids.($need_update_uids?','.dimplode($need_update_uids):'');
		if ($update_uids){
			DB::query('UPDATE '.DB::table("common_member").' SET groupid='.$config['vip_group'].' WHERE uid IN ('.$update_uids.')');
		}
		cpmsg("dsu_kkvip:tools_inc_php_1",'','succeed');
	}
	if (submitcheck('add_czz') && intval($_G['gp_add_czz'])==$_G['gp_add_czz']){
		include_once DISCUZ_ROOT.'./source/plugin/dsu_kkvip/vip.func.php';
		add_czz_vip($uid_array,$_G['gp_add_czz']);
		cpmsg("dsu_kkvip:tools_inc_php_2",'','succeed');
	}
	if (submitcheck('del') && intval($_G['gp_add_czz'])==$_G['gp_add_czz']){
		$ids=dimplode($uid_array);
		DB::query('UPDATE '.DB::table("common_member").' m, '.DB::table("dsu_kkvip").' v SET m.groupid=v.oldgroup WHERE m.uid=v.uid AND m.uid IN ('.$ids.')');
		DB::query('DELETE FROM '.DB::table("dsu_kkvip").' WHERE uid IN ('.$ids.')');
		cpmsg("dsu_kkvip:tools_inc_php_12",'','succeed');
	}
}
showsubmenusteps('VIP '.lang("plugin/dsu_kkvip","tools_inc_php_9"), array(
	array('nav_members_select', !$_G['gp_submit']),
	array(lang("plugin/dsu_kkvip","tools_inc_php_3"), $_G['gp_submit']),
));
showsearchform();
if(submitcheck('submit', 1)) {
	$membernum = countmembers($search_condition, $urladd);
	if(!$membernum) {
		cpmsg('members_search_nonexistence');
	}
	showtableheader(lang("plugin/dsu_kkvip","tools_inc_php_4"));
	showtablerow('', 'class="lineheight"', '<li><font color="red"><b>'.lang("plugin/dsu_kkvip","tools_inc_php_10").' '.$membernum.' '.lang("plugin/dsu_kkvip","tools_inc_php_11").'</b></font></li>');
	showtablefooter();
	$uidarray=searchmembers($search_condition);
	$uids=implode('|',$uidarray);
	showtableheader(lang("plugin/dsu_kkvip","tools_inc_php_5"));
	showformheader('plugins&operation=config&identifier=dsu_kkvip&pmod=tools&uids='.$uids.$urladd);
	showhiddenfields(array('uid_array'=>$uids));
	showsetting(lang("plugin/dsu_kkvip","tools_inc_php_6"),'month','1','text');
	showsubmit('tools_submit', 'submit');
	showformfooter();
	showtablefooter();
	showtableheader(lang("plugin/dsu_kkvip","tools_inc_php_7"));
	showformheader('plugins&operation=config&identifier=dsu_kkvip&pmod=tools&uids='.$uids.$urladd);
	showhiddenfields(array('uid_array'=>$uids));
	showsetting(lang("plugin/dsu_kkvip","tools_inc_php_8"),'add_czz','10','text');
	showsubmit('tools_submit', 'submit');
	showformfooter();
	showtablefooter();
	showtableheader(lang("plugin/dsu_kkvip","tools_inc_php_13"));
	showformheader('plugins&operation=config&identifier=dsu_kkvip&pmod=tools&del=yes&uids='.$uids.$urladd);
	showhiddenfields(array('uid_array'=>$uids));
	showsubmit('tools_submit', lang("plugin/dsu_kkvip","tools_inc_php_14"));
	showformfooter();
	showtablefooter();
	exit();
}
showtablefooter();
showformfooter();

function check_post_array($array){
	foreach($array as $value){
		if (is_array($value)) return false;
		$value_int=intval($value);
		if ($value_int!=$value) return false;
	}
	return true;
}

function array_remove($from_array,$remove_array){
	$flip_array=array_flip($from_array);
	foreach($remove_array as $remove_str){
		unset($flip_array[$remove_str]);
	}
	return array_flip($flip_array);
}

function showsearchform($operation = '') {
	global $_G, $lang;

	$groupselect = array();
	$usergroupid = isset($_G['gp_usergroupid']) && is_array($_G['gp_usergroupid']) ? $_G['gp_usergroupid'] : array();
	$query = DB::query("SELECT type, groupid, grouptitle, radminid FROM ".DB::table('common_usergroup')." WHERE groupid NOT IN ('6', '7') ORDER BY (creditshigher<>'0' || creditslower<>'0'), creditslower, groupid");
	while($group = DB::fetch($query)) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(in_array($group['groupid'], $usergroupid) ? 'selected' : '').">$group[grouptitle]</option>\n";
	}
	$groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';

	showtagheader('div', 'searchmembers', !$_G['gp_submit']);
	echo '<script src="static/js/forum_calendar.js" type="text/javascript"></script>';
	showformheader("plugins&operation=config&identifier=dsu_kkvip&pmod=tools");
	showtableheader();
	showsetting('members_search_user', 'username', $_G['gp_username'], 'text');
	showsetting('members_search_uid', 'uid', $_G['gp_uid'], 'text');
	showsetting('members_search_group', '', '', '<select name="groupid[]" multiple="multiple" size="10"><option value="all"'.(in_array('all', $usergroupid) ? ' selected' : '').'>'.cplang('unlimited').'</option>'.$groupselect.'</select>');

	showtagheader('tbody', 'advanceoption');
	showsetting('members_search_email', 'email', $_G['gp_email'], 'text');
	showsetting("$lang[credits] $lang[members_search_between]", array("credits_low", "credits_high"), array($_G['gp_credits_low'], $_G['gp_credtis_high']), 'range');

	if(!empty($_G['setting']['extcredits'])) {
		foreach($_G['setting']['extcredits'] as $id => $credit) {
			showsetting("$credit[title] $lang[members_search_between]", array("extcredits$id"."_low", "extcredits$id"."_high"), array($_G['gp_extcredits'.$id.'_low'], $_G['gp_extcredits'.$id.'_high']), 'range');
		}
	}

	showsetting('members_search_postsrange', array('posts_low', 'posts_high'), array($_G['gp_posts_high'], $_G['gp_posts_low']), 'range');
	showsetting('members_search_regip', 'regip', $_G['gp_regip'], 'text');
	showsetting('members_search_lastip', 'lastip', $_G['gp_lastip'], 'text');
	showsetting('members_search_regdaterange', array('regdate_after', 'regdate_before'), array($_G['gp_regdate_after'], $_G['gp_regdate_before']), 'daterange');
	showsetting('members_search_lastvisitrange', array('lastvisit_after', 'lastvisit_before'), array($_G['gp_lastvisit_after'], $_G['gp_lastvisit_before']), 'daterange');
	showsetting('members_search_lastpostrange', array('lastpost_after', 'lastpost_before'), array($_G['gp_lastpost_after'], $_G['gp_lastpost_before']), 'daterange');

	$yearselect = $monthselect = $dayselect = "<option value=\"\">".cplang('nolimit')."</option>\n";
	$yy=dgmdate(TIMESTAMP, 'Y');
	for($y=$yy; $y>=$yy-100; $y--) {
		$y = sprintf("%04d", $y);
		$yearselect .= "<option value=\"$y\" ".($_G['gp_birthyear'] == $y ? 'selected' : '').">$y</option>\n";
	}
	for($m=1; $m<=12; $m++) {
		$m = sprintf("%02d", $m);
		$monthselect .= "<option value=\"$m\" ".($_G['gp_birthmonth'] == $m ? 'selected' : '').">$m</option>\n";
	}
	for($d=1; $d<=31; $d++) {
		$d = sprintf("%02d", $d);
		$dayselect .= "<option value=\"$d\" ".($_G['gp_birthday'] == $d ? 'selected' : '').">$d</option>\n";
	}
	showsetting('members_search_birthday', '', '', '<select class="txt" name="birthyear" style="width:75px; margin-right:0">'.$yearselect.'</select> '.$lang['year'].' <select class="txt" name="birthmonth" style="width:75px; margin-right:0">'.$monthselect.'</select> '.$lang['month'].' <select class="txt" name="birthday" style="width:75px; margin-right:0">'.$dayselect.'</select> '.$lang['day']);

	loadcache('profilesetting');
	unset($_G['cache']['profilesetting']['uid']);
	unset($_G['cache']['profilesetting']['birthyear']);
	unset($_G['cache']['profilesetting']['birthmonth']);
	unset($_G['cache']['profilesetting']['birthday']);
	foreach($_G['cache']['profilesetting'] as $fieldid=>$value) {
		if($fieldid == 'gender') {
			$select = "<option value=\"\">".cplang('nolimit')."</option>\n";
			$select .= "<option value=\"0\">".cplang('members_edit_gender_secret')."</option>\n";
			$select .= "<option value=\"1\">".cplang('members_edit_gender_male')."</option>\n";
			$select .= "<option value=\"2\">".cplang('members_edit_gender_female')."</option>\n";
			showsetting($value['title'], '', '', '<select class="txt" name="gender">'.$select.'</select>');
		} elseif($fieldid == 'constellation') {
			$select = "<option value=\"\">".cplang('nolimit')."</option>\n";
			for($i=1; $i<=12; $i++) {
				$name = lang('space', 'constellation_'.$i);
				$select .= "<option value=\"$name\">$name</option>\n";
			}
			showsetting($value['title'], '', '', '<select class="txt" name="constellation">'.$select.'</select>');
		} elseif($fieldid == 'zodiac') {
			$select = "<option value=\"\">".cplang('nolimit')."</option>\n";
			for($i=1; $i<=12; $i++) {
				$option = lang('space', 'zodiac_'.$i);
				$select .= "<option value=\"$option\">$option</option>\n";
			}
			showsetting($value['title'], '', '', '<select class="txt" name="zodiac">'.$select.'</select>');
		} elseif($value['formtype'] == 'select' || $value['formtype'] == 'list') {
			$select = "<option value=\"\">".cplang('nolimit')."</option>\n";
			$value['choices'] = explode("\n",$value['choices']);
			foreach($value['choices'] as $option) {
				$option = trim($option);
				$select .= "<option value=\"$option\">$option</option>\n";
			}
			showsetting($value['title'], '', '', '<select class="txt" name="'.$fieldid.'">'.$select.'</select>');
		} else {
			showsetting($value['title'], '', '', '<input class="txt" name="'.$fieldid.'" />');
		}
	}
	showtagfooter('tbody');
	showsubmit('submit', $operation == 'clean' ? 'members_delete' : 'search', '', 'more_options');
	showtablefooter();
	showformfooter();
	showtagfooter('div');
}

function searchmembers($condition, $limit=5000, $start=0) {
	include_once libfile('class/membersearch');
	$ms = new membersearch();
	return $ms->search($condition, $limit, $start);
}

function countmembers($condition, &$urladd) {

	$urladd = '';
	foreach($condition as $k => $v) {
		if(in_array($k, array('formhash', 'submit', 'page')) || $v === '') {
			continue;
		}
		if(is_array($v)) {
			foreach($v as $vk => $vv) {
				if($vv === '') {
					continue;
				}
				$urladd .= '&'.$k.'['.$vk.']='.rawurlencode($vv);
			}
		} else {
			$urladd .= '&'.$k.'='.rawurlencode($v);
		}
	}
	include_once libfile('class/membersearch');
	$ms = new membersearch();
	return $ms->getcount($condition);
}
if(!function_exists('dimplode')){
	function dimplode($array) {
		if(!empty($array)) {
			return "'".implode("','", is_array($array) ? $array : array($array))."'";
		} else {
			return 0;
		}
	}
}