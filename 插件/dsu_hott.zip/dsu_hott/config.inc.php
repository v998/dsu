<?php
/*
 * KK Plugin Setting File
 */
$hott=array (
  0 => 
  array (
    'style' => 'default',
  ),
  1 => 
  array (
    'title' => '&#27004;&#20027;&#28909;&#24086;',
    'only_lz' => '1',
    'orderby' => '2',
  ),
  2 => 
  array (
    'title' => '&#35770;&#22363;&#26032;&#24086;',
    'only_lz' => '0',
    'orderby' => '3',
  ),
)
?>